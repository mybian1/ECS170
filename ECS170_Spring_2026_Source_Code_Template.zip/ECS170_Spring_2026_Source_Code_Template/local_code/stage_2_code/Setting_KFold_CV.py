'''
Concrete SettingModule class for a specific experimental SettingModule
'''

# Copyright (c) 2017-Current Jiawei Zhang <jiawei@ifmlab.org>
# License: TBD

from local_code.base_class.setting import setting
from sklearn.model_selection import KFold
import numpy as np


    
def load_run_save_evaluate(self):

    # load pre-split train/test dataset
    loaded_data = self.dataset.load()

    # run MethodModule directly, no K-Fold
    self.method.data = loaded_data
    learned_result = self.method.run()

    # save raw ResultModule
    self.result.data = learned_result
    self.result.fold_count = None
    self.result.save()

    # evaluate
    self.evaluate.data = learned_result
    score = self.evaluate.evaluate()

    return score, None
        