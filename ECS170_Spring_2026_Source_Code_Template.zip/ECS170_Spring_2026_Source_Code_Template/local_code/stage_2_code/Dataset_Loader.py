'''
Concrete IO class for a specific dataset
'''

# Copyright (c) 2017-Current Jiawei Zhang <jiawei@ifmlab.org>
# License: TBD

import pandas as pd
import numpy as np
from local_code.base_class.dataset import dataset


class Dataset_Loader(dataset):
    data = None
    dataset_source_folder_path = None
    dataset_source_file_name = None
    
    def __init__(self, dName=None, dDescription=None):
        super().__init__(dName, dDescription)
    
    def load(self):
        print('loading data...')

        train = pd.read_csv(self.dataset_source_folder_path + "train.csv", header=None)
        test = pd.read_csv(self.dataset_source_folder_path + "test.csv", header=None)

        train_X = train.iloc[:, 1:].values / 255.0
        train_y = train.iloc[:, 0].values

        test_X = test.iloc[:, 1:].values / 255.0
        test_y = test.iloc[:, 0].values

        return {
            'train': {'X': train_X, 'y': train_y},
            'test': {'X': test_X, 'y': test_y}
    }