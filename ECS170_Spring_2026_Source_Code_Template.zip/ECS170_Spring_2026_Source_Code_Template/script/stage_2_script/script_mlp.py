from local_code.stage_2_code.Dataset_Loader import Dataset_Loader
from local_code.stage_2_code.Method_MLP import Method_MLP
from local_code.stage_2_code.Result_Saver import Result_Saver
from local_code.stage_2_code.Evaluate_Accuracy import Evaluate_Accuracy
import numpy as np
import torch

if __name__ == '__main__':

    np.random.seed(2)
    torch.manual_seed(2)

    # load dataset (Stage 2)
    data_obj = Dataset_Loader('digit', '')
    data_obj.dataset_source_folder_path = 'data/stage_2_data/'

    loaded_data = data_obj.load()

    # model
    method_obj = Method_MLP('MLP', '')
    method_obj.data = loaded_data

    print('************ Start ************')
    result = method_obj.run()

    # evaluate
    evaluate_obj = Evaluate_Accuracy('evaluation', '')
    evaluate_obj.data = result

    print('************ Performance ************')
    score = evaluate_obj.evaluate()
    print('Accuracy:', score)

    print('************ Finish ************')