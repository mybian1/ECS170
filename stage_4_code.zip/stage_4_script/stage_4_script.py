

import sys
from pathlib import Path


def main():
    root_dir = Path(__file__).resolve().parents[2]
    code_dir = root_dir / "local_code" / "stage_4_code"

    sys.path.insert(0, str(code_dir))

    from main_stage4 import run_stage4

    # First run:
    #   fast_test=True
    # This checks that your folder path and code are correct.
    #
    # Final report run:
    #   change fast_test=True to fast_test=False
    run_stage4(
        root_dir=root_dir,
        fast_test=False
    )


if __name__ == "__main__":
    main()
