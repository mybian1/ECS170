import os
import re
import csv
from pathlib import Path
from collections import Counter

import torch
import numpy as np
import matplotlib.pyplot as plt

from torch import nn
from torch.utils.data import Dataset, DataLoader


def read_generation_text(text_file):
    """
    The uploaded text_generation/data file is CSV-like:
        "ID","Joke"
        1,"..."

    This function uses the Joke column as the text-generation corpus.
    If reading as CSV fails, it reads the file as normal text.
    """
    text_file = Path(text_file)

    if not text_file.exists():
        raise FileNotFoundError(f"Cannot find generation file: {text_file}")

    try:
        jokes = []

        with text_file.open("r", encoding="utf-8", errors="ignore", newline="") as f:
            reader = csv.DictReader(f)

            for row in reader:
                if "Joke" in row and row["Joke"]:
                    jokes.append(row["Joke"])

        if len(jokes) > 0:
            return " ".join(jokes)

    except Exception:
        pass

    return text_file.read_text(encoding="utf-8", errors="ignore")


def tokenize_text(text):
    text = text.lower()
    text = re.sub(r"[^a-zA-Z0-9\s']", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text.split()


class WordVocab:
    def __init__(self, min_freq=1, max_size=10000):
        self.min_freq = min_freq
        self.max_size = max_size
        self.word2idx = {
            "<PAD>": 0,
            "<UNK>": 1
        }
        self.idx2word = {
            0: "<PAD>",
            1: "<UNK>"
        }

    def build_vocab(self, tokens):
        counter = Counter(tokens)

        for word, freq in counter.most_common(self.max_size):
            if freq >= self.min_freq and word not in self.word2idx:
                index = len(self.word2idx)
                self.word2idx[word] = index
                self.idx2word[index] = word

    def encode(self, tokens):
        return [
            self.word2idx.get(token, self.word2idx["<UNK>"])
            for token in tokens
        ]

    def __len__(self):
        return len(self.word2idx)


class TextGenerationDataset(Dataset):
    def __init__(self, token_ids, sequence_length=3):
        self.inputs = []
        self.targets = []

        for i in range(len(token_ids) - sequence_length):
            self.inputs.append(token_ids[i:i + sequence_length])
            self.targets.append(token_ids[i + sequence_length])

    def __len__(self):
        return len(self.inputs)

    def __getitem__(self, index):
        return {
            "input": torch.tensor(self.inputs[index], dtype=torch.long),
            "target": torch.tensor(self.targets[index], dtype=torch.long)
        }


class RNNTextGenerator(nn.Module):
    def __init__(
        self,
        vocab_size,
        embed_dim,
        hidden_dim,
        model_type="RNN",
        num_layers=1,
        dropout=0.3
    ):
        super().__init__()

        self.model_type = model_type.upper()

        self.embedding = nn.Embedding(
            num_embeddings=vocab_size,
            embedding_dim=embed_dim,
            padding_idx=0
        )

        if self.model_type == "RNN":
            rnn_layer = nn.RNN
        elif self.model_type == "LSTM":
            rnn_layer = nn.LSTM
        elif self.model_type == "GRU":
            rnn_layer = nn.GRU
        else:
            raise ValueError("model_type must be RNN, LSTM, or GRU")

        self.rnn = rnn_layer(
            input_size=embed_dim,
            hidden_size=hidden_dim,
            num_layers=num_layers,
            batch_first=True,
            dropout=dropout if num_layers > 1 else 0
        )

        self.dropout = nn.Dropout(dropout)
        self.fc = nn.Linear(hidden_dim, vocab_size)

    def forward(self, x):
        embedded = self.embedding(x)

        output, hidden = self.rnn(embedded)

        last_output = output[:, -1, :]
        last_output = self.dropout(last_output)

        logits = self.fc(last_output)
        return logits


def generate_text(
    model,
    vocab,
    start_words,
    sequence_length,
    generate_length=40,
    temperature=0.8,
    device="cpu"
):
    model.eval()

    words = tokenize_text(start_words)

    if len(words) == 0:
        raise ValueError("start_words must contain at least one word.")

    for _ in range(generate_length):
        input_words = words[-sequence_length:]

        if len(input_words) < sequence_length:
            input_words = ["<PAD>"] * (sequence_length - len(input_words)) + input_words

        input_ids = [
            vocab.word2idx.get(word, vocab.word2idx["<UNK>"])
            for word in input_words
        ]

        x = torch.tensor([input_ids], dtype=torch.long).to(device)

        with torch.no_grad():
            logits = model(x)
            logits = logits / temperature

            probs = torch.softmax(logits, dim=1).cpu().numpy()[0]

            # Avoid PAD and UNK during generation.
            probs[0] = 0
            probs[1] = 0

            if probs.sum() == 0:
                break

            probs = probs / probs.sum()

            next_id = np.random.choice(len(probs), p=probs)
            next_word = vocab.idx2word.get(next_id, "<UNK>")

        words.append(next_word)

    return " ".join(words)


def plot_loss_curve(losses, save_path, title):
    plt.figure()
    plt.plot(range(1, len(losses) + 1), losses, marker="o")
    plt.xlabel("Epoch")
    plt.ylabel("Training Loss")
    plt.title(title)
    plt.grid(True)
    plt.savefig(save_path, bbox_inches="tight")
    plt.close()


def train_generation_model(
    text_file,
    model_type="RNN",
    result_dir="result",
    sequence_length=3,
    embed_dim=128,
    hidden_dim=128,
    num_layers=1,
    batch_size=64,
    epochs=20,
    learning_rate=0.001,
    max_vocab_size=10000,
    start_words="what did the",
    generate_length=40,
    temperature=0.8
):
    os.makedirs(result_dir, exist_ok=True)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print("Using device:", device)

    raw_text = read_generation_text(text_file)
    tokens = tokenize_text(raw_text)

    print(f"Total generation tokens: {len(tokens)}")

    vocab = WordVocab(min_freq=1, max_size=max_vocab_size)
    vocab.build_vocab(tokens)

    print(f"Generation vocabulary size: {len(vocab)}")

    token_ids = vocab.encode(tokens)

    dataset = TextGenerationDataset(
        token_ids=token_ids,
        sequence_length=sequence_length
    )

    loader = DataLoader(
        dataset,
        batch_size=batch_size,
        shuffle=True
    )

    model = RNNTextGenerator(
        vocab_size=len(vocab),
        embed_dim=embed_dim,
        hidden_dim=hidden_dim,
        model_type=model_type,
        num_layers=num_layers
    ).to(device)

    criterion = nn.CrossEntropyLoss()
    optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate)

    losses = []

    for epoch in range(epochs):
        model.train()
        total_loss = 0.0

        for batch in loader:
            inputs = batch["input"].to(device)
            targets = batch["target"].to(device)

            optimizer.zero_grad()

            logits = model(inputs)
            loss = criterion(logits, targets)

            loss.backward()
            optimizer.step()

            total_loss += loss.item()

        average_loss = total_loss / len(loader)
        losses.append(average_loss)

        print(
            f"{model_type} generation "
            f"epoch [{epoch + 1}/{epochs}], "
            f"loss = {average_loss:.4f}"
        )

    loss_path = Path(result_dir) / f"{model_type}_generation_loss.png"
    plot_loss_curve(
        losses=losses,
        save_path=loss_path,
        title=f"{model_type} Text Generation Learning Curve"
    )

    generated_text = generate_text(
        model=model,
        vocab=vocab,
        start_words=start_words,
        sequence_length=sequence_length,
        generate_length=generate_length,
        temperature=temperature,
        device=device
    )

    story_path = Path(result_dir) / f"{model_type}_generated_text.txt"

    with open(story_path, "w", encoding="utf-8") as f:
        f.write(f"Model: {model_type}\n")
        f.write(f"Starting words: {start_words}\n")
        f.write(f"Temperature: {temperature}\n\n")
        f.write(generated_text)

    model_path = Path(result_dir) / f"{model_type}_generation_model.pt"
    torch.save(model.state_dict(), model_path)

    print("\nGenerated text:")
    print(generated_text)

    return {
        "generated_text": generated_text,
        "loss_path": str(loss_path),
        "story_path": str(story_path),
        "model_path": str(model_path)
    }
