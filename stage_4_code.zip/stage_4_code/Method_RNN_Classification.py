import os
import re
from pathlib import Path
from collections import Counter

import torch
import matplotlib.pyplot as plt

from torch import nn
from torch.utils.data import Dataset, DataLoader
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    classification_report,
    confusion_matrix
)


def clean_text(text):
    text = str(text).lower()
    text = re.sub(r"<.*?>", " ", text)
    text = re.sub(r"[^a-zA-Z0-9\s']", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text


def load_text_classification_folder(data_root, split, max_per_class=None):
    """
    Expected folder format:

    text_classification/
        train/
            neg/*.txt
            pos/*.txt
        test/
            neg/*.txt
            pos/*.txt

    Label mapping:
        neg -> 0
        pos -> 1
    """
    data_root = Path(data_root)

    texts = []
    labels = []

    for folder_name, label in [("neg", 0), ("pos", 1)]:
        folder = data_root / split / folder_name

        if not folder.exists():
            raise FileNotFoundError(f"Cannot find folder: {folder}")

        files = sorted(folder.glob("*.txt"))

        if max_per_class is not None:
            files = files[:max_per_class]

        for file_path in files:
            text = file_path.read_text(encoding="utf-8", errors="ignore")
            texts.append(text)
            labels.append(label)

    return texts, labels


class TextVocab:
    def __init__(self, min_freq=1, max_size=30000):
        self.min_freq = min_freq
        self.max_size = max_size
        self.word2idx = {
            "<PAD>": 0,
            "<UNK>": 1
        }
        self.idx2word = {
            0: "<PAD>",
            1: "<UNK>"
        }

    def build_vocab(self, texts):
        counter = Counter()

        for text in texts:
            tokens = clean_text(text).split()
            counter.update(tokens)

        for word, freq in counter.most_common(self.max_size):
            if freq >= self.min_freq and word not in self.word2idx:
                index = len(self.word2idx)
                self.word2idx[word] = index
                self.idx2word[index] = word

    def encode(self, text, max_len):
        tokens = clean_text(text).split()
        token_ids = [
            self.word2idx.get(token, self.word2idx["<UNK>"])
            for token in tokens
        ]

        if len(token_ids) < max_len:
            token_ids += [self.word2idx["<PAD>"]] * (max_len - len(token_ids))
        else:
            token_ids = token_ids[:max_len]

        return token_ids

    def __len__(self):
        return len(self.word2idx)


class TextClassificationDataset(Dataset):
    def __init__(self, texts, labels, vocab, max_len):
        self.texts = texts
        self.labels = labels
        self.vocab = vocab
        self.max_len = max_len

    def __len__(self):
        return len(self.texts)

    def __getitem__(self, index):
        token_ids = self.vocab.encode(self.texts[index], self.max_len)

        return {
            "text": torch.tensor(token_ids, dtype=torch.long),
            "label": torch.tensor(self.labels[index], dtype=torch.long)
        }


class RNNTextClassifier(nn.Module):
    def __init__(
        self,
        vocab_size,
        embed_dim,
        hidden_dim,
        num_classes=2,
        model_type="RNN",
        num_layers=1,
        dropout=0.3
    ):
        super().__init__()

        self.model_type = model_type.upper()

        self.embedding = nn.Embedding(
            num_embeddings=vocab_size,
            embedding_dim=embed_dim,
            padding_idx=0
        )

        if self.model_type == "RNN":
            rnn_layer = nn.RNN
        elif self.model_type == "LSTM":
            rnn_layer = nn.LSTM
        elif self.model_type == "GRU":
            rnn_layer = nn.GRU
        else:
            raise ValueError("model_type must be RNN, LSTM, or GRU")

        self.rnn = rnn_layer(
            input_size=embed_dim,
            hidden_size=hidden_dim,
            num_layers=num_layers,
            batch_first=True,
            dropout=dropout if num_layers > 1 else 0
        )

        self.dropout = nn.Dropout(dropout)
        self.fc = nn.Linear(hidden_dim, num_classes)

    def forward(self, x):
        embedded = self.embedding(x)

        output, hidden = self.rnn(embedded)

        if self.model_type == "LSTM":
            hidden = hidden[0]

        last_hidden = hidden[-1]
        last_hidden = self.dropout(last_hidden)

        logits = self.fc(last_hidden)
        return logits


def plot_loss_curve(losses, save_path, title):
    plt.figure()
    plt.plot(range(1, len(losses) + 1), losses, marker="o")
    plt.xlabel("Epoch")
    plt.ylabel("Training Loss")
    plt.title(title)
    plt.grid(True)
    plt.savefig(save_path, bbox_inches="tight")
    plt.close()


def train_classification_model(
    data_root,
    model_type="RNN",
    result_dir="result",
    max_len=250,
    embed_dim=128,
    hidden_dim=128,
    num_layers=1,
    batch_size=64,
    epochs=5,
    learning_rate=0.001,
    max_vocab_size=30000,
    max_train_per_class=None,
    max_test_per_class=None
):
    os.makedirs(result_dir, exist_ok=True)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print("Using device:", device)

    train_texts, train_labels = load_text_classification_folder(
        data_root=data_root,
        split="train",
        max_per_class=max_train_per_class
    )

    test_texts, test_labels = load_text_classification_folder(
        data_root=data_root,
        split="test",
        max_per_class=max_test_per_class
    )

    print(f"Train samples: {len(train_texts)}")
    print(f"Test samples : {len(test_texts)}")
    print("Label mapping: neg = 0, pos = 1")

    vocab = TextVocab(min_freq=1, max_size=max_vocab_size)
    vocab.build_vocab(train_texts)

    print(f"Vocabulary size: {len(vocab)}")

    train_dataset = TextClassificationDataset(
        texts=train_texts,
        labels=train_labels,
        vocab=vocab,
        max_len=max_len
    )

    test_dataset = TextClassificationDataset(
        texts=test_texts,
        labels=test_labels,
        vocab=vocab,
        max_len=max_len
    )

    train_loader = DataLoader(
        train_dataset,
        batch_size=batch_size,
        shuffle=True
    )

    test_loader = DataLoader(
        test_dataset,
        batch_size=batch_size,
        shuffle=False
    )

    model = RNNTextClassifier(
        vocab_size=len(vocab),
        embed_dim=embed_dim,
        hidden_dim=hidden_dim,
        num_classes=2,
        model_type=model_type,
        num_layers=num_layers
    ).to(device)

    criterion = nn.CrossEntropyLoss()
    optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate)

    train_losses = []

    for epoch in range(epochs):
        model.train()
        total_loss = 0.0

        for batch in train_loader:
            texts = batch["text"].to(device)
            labels = batch["label"].to(device)

            optimizer.zero_grad()

            logits = model(texts)
            loss = criterion(logits, labels)

            loss.backward()
            optimizer.step()

            total_loss += loss.item()

        average_loss = total_loss / len(train_loader)
        train_losses.append(average_loss)

        print(
            f"{model_type} classification "
            f"epoch [{epoch + 1}/{epochs}], "
            f"loss = {average_loss:.4f}"
        )

    model.eval()
    predictions = []
    gold_labels = []

    with torch.no_grad():
        for batch in test_loader:
            texts = batch["text"].to(device)
            labels = batch["label"].to(device)

            logits = model(texts)
            preds = torch.argmax(logits, dim=1)

            predictions.extend(preds.cpu().numpy())
            gold_labels.extend(labels.cpu().numpy())

    accuracy = accuracy_score(gold_labels, predictions)
    precision = precision_score(
        gold_labels,
        predictions,
        average="macro",
        zero_division=0
    )
    recall = recall_score(
        gold_labels,
        predictions,
        average="macro",
        zero_division=0
    )
    f1 = f1_score(
        gold_labels,
        predictions,
        average="macro",
        zero_division=0
    )

    cm = confusion_matrix(gold_labels, predictions)

    report = classification_report(
        gold_labels,
        predictions,
        target_names=["negative", "positive"],
        zero_division=0
    )

    print("\nClassification Evaluation")
    print(f"Accuracy : {accuracy:.4f}")
    print(f"Precision: {precision:.4f}")
    print(f"Recall   : {recall:.4f}")
    print(f"F1-score : {f1:.4f}")
    print("Confusion matrix:")
    print(cm)
    print(report)

    loss_path = Path(result_dir) / f"{model_type}_classification_loss.png"
    plot_loss_curve(
        losses=train_losses,
        save_path=loss_path,
        title=f"{model_type} Classification Learning Curve"
    )

    report_path = Path(result_dir) / f"{model_type}_classification_report.txt"

    with open(report_path, "w", encoding="utf-8") as f:
        f.write(f"Model: {model_type}\n")
        f.write("Task: Text Classification\n")
        f.write("Label mapping: neg = 0, pos = 1\n\n")
        f.write(f"Accuracy : {accuracy:.4f}\n")
        f.write(f"Precision: {precision:.4f}\n")
        f.write(f"Recall   : {recall:.4f}\n")
        f.write(f"F1-score : {f1:.4f}\n\n")
        f.write("Confusion matrix:\n")
        f.write(str(cm))
        f.write("\n\nClassification report:\n")
        f.write(report)

    model_path = Path(result_dir) / f"{model_type}_classification_model.pt"
    torch.save(model.state_dict(), model_path)

    return {
        "accuracy": accuracy,
        "precision": precision,
        "recall": recall,
        "f1": f1,
        "loss_path": str(loss_path),
        "report_path": str(report_path),
        "model_path": str(model_path)
    }
