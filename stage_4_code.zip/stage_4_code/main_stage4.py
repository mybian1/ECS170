from pathlib import Path

from Method_RNN_Classification import train_classification_model
from Method_RNN_Generation import train_generation_model


def run_stage4(
    root_dir=None,
    fast_test=False
):
   

    if root_dir is None:
        # main_stage4.py is inside local_code/stage_4_code.
        root_dir = Path(__file__).resolve().parents[2]
    else:
        root_dir = Path(root_dir).resolve()

    data_root = root_dir / "data" / "stage_4_data"
    classification_data_root = data_root / "text_classification"
    generation_text_file = data_root / "text_generation" / "data"

    result_dir = root_dir / "result" / "stage_4_result"
    result_dir.mkdir(parents=True, exist_ok=True)

    print("Project root:", root_dir)
    print("Classification data:", classification_data_root)
    print("Generation data:", generation_text_file)
    print("Result folder:", result_dir)

    model_types = ["RNN", "LSTM", "GRU"]

    # Use fast_test=True to quickly check that the code works.
    # Use fast_test=False for final report results.
    if fast_test:
        classification_epochs = 1
        generation_epochs = 1
        max_train_per_class = 500
        max_test_per_class = 200
    else:
        classification_epochs = 25
        generation_epochs = 20
        max_train_per_class = None
        max_test_per_class = None

    classification_results = {}
    generation_results = {}

    for model_type in model_types:
        print("\n" + "=" * 70)
        print(f"{model_type}: Text Classification")
        print("=" * 70)

        classification_results[model_type] = train_classification_model(
            data_root=classification_data_root,
            model_type=model_type,
            result_dir=result_dir,
            max_len=250,
            embed_dim=128,
            hidden_dim=256,
            num_layers=1,
            batch_size=64,
            epochs=classification_epochs,
            learning_rate=0.001,
            max_vocab_size=30000,
            max_train_per_class=max_train_per_class,
            max_test_per_class=max_test_per_class
        )

        print("\n" + "=" * 70)
        print(f"{model_type}: Text Generation")
        print("=" * 70)

        generation_results[model_type] = train_generation_model(
            text_file=generation_text_file,
            model_type=model_type,
            result_dir=result_dir,
            sequence_length=3,
            embed_dim=128,
            hidden_dim=128,
            num_layers=1,
            batch_size=64,
            epochs=generation_epochs,
            learning_rate=0.001,
            max_vocab_size=10000,
            start_words="what did the",
            generate_length=40,
            temperature=0.8
        )

    summary_path = result_dir / "stage4_summary.txt"

    with open(summary_path, "w", encoding="utf-8") as f:
        f.write("Stage 4 Summary\n")
        f.write("================\n\n")

        f.write("Text Classification Results\n")
        f.write("---------------------------\n")

        for model_type, result in classification_results.items():
            f.write(f"{model_type}\n")
            f.write(f"Accuracy : {result['accuracy']:.4f}\n")
            f.write(f"Precision: {result['precision']:.4f}\n")
            f.write(f"Recall   : {result['recall']:.4f}\n")
            f.write(f"F1-score : {result['f1']:.4f}\n\n")

        f.write("\nText Generation Results\n")
        f.write("-----------------------\n")

        for model_type, result in generation_results.items():
            f.write(f"{model_type}\n")
            f.write(result["generated_text"])
            f.write("\n\n")

    print("\nDone.")
    print("Summary saved to:", summary_path)

    return classification_results, generation_results


if __name__ == "__main__":
    # Set fast_test=True first to make sure everything runs.
    # For the final report, change to fast_test=False.
    run_stage4(fast_test=True)
