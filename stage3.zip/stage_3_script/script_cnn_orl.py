from local_code.stage_3_code.Dataset_Loader_Image import Dataset_Loader_Image
from local_code.stage_3_code.Method_CNN import Method_CNN
from local_code.stage_3_code.Evaluate_Accuracy import Evaluate_Accuracy
import matplotlib.pyplot as plt
import numpy as np
import torch


if __name__ == "__main__":
    np.random.seed(2)
    torch.manual_seed(2)

    data_obj = Dataset_Loader_Image("ORL", "")
    data_obj.dataset_source_folder_path = "data/stage_3_data/"
    data_obj.dataset_source_file_name = "ORL"

    data = data_obj.load()

    num_classes = len(set(data["train"]["y"]))

    image_height = data["train"]["X"].shape[2]
    image_width = data["train"]["X"].shape[3]

    model = Method_CNN(
    "CNN ORL",
    "",
    input_channel=1,
    num_classes=num_classes,
    image_height=image_height,
    image_width=image_width
    )

    model.max_epoch = 30
    model.data = data

    result = model.run()

    evaluator = Evaluate_Accuracy("evaluation", "")
    evaluator.data = result
    evaluator.evaluate()

    plt.plot(range(len(result["loss_list"])), result["loss_list"])
    plt.xlabel("Epoch")
    plt.ylabel("Loss")
    plt.title("ORL CNN Training Convergence")
    plt.grid(True)
    plt.savefig("result/stage_3_result/orl_cnn_loss.png")
    plt.show()