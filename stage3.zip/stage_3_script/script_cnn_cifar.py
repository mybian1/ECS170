from local_code.stage_3_code.Dataset_Loader_Image import Dataset_Loader_Image
from local_code.stage_3_code.Method_CNN import Method_CNN
from local_code.stage_3_code.Evaluate_Accuracy import Evaluate_Accuracy
import matplotlib.pyplot as plt
import numpy as np
import torch


if __name__ == "__main__":
    np.random.seed(2)
    torch.manual_seed(2)

    data_obj = Dataset_Loader_Image("CIFAR", "")
    data_obj.dataset_source_folder_path = "data/stage_3_data/"
    data_obj.dataset_source_file_name = "CIFAR"

    data = data_obj.load()

    model = Method_CNN("CNN CIFAR", "", input_channel=3, num_classes=10, image_height=32, image_width=32)
    model.max_epoch = 30
    model.data = data

    result = model.run()

    evaluator = Evaluate_Accuracy("evaluation", "")
    evaluator.data = result
    evaluator.evaluate()

    plt.plot(range(len(result["loss_list"])), result["loss_list"])
    plt.xlabel("Epoch")
    plt.ylabel("Loss")
    plt.title("CIFAR CNN Training Convergence")
    plt.grid(True)
    plt.savefig("result/stage_3_result/cifar_cnn_loss.png")
    plt.show()