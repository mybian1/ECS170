from local_code.stage_3_code.Dataset_Loader_Image import Dataset_Loader_Image
from local_code.stage_3_code.Method_CNN import Method_CNN
from local_code.stage_3_code.Evaluate_Accuracy import Evaluate_Accuracy

import matplotlib.pyplot as plt
import numpy as np
import torch


if __name__ == "__main__":

    np.random.seed(2)
    torch.manual_seed(2)

    # load dataset
    data_obj = Dataset_Loader_Image("MNIST", "")
    data_obj.dataset_source_folder_path = "data/stage_3_data/"
    data_obj.dataset_source_file_name = "MNIST"

    data = data_obj.load()

    # CNN model
    model = Method_CNN("CNN MNIST", "", input_channel=1, num_classes=10, image_height=28, image_width=28)

    model.data = data

    print("************ Start ************")
    result = model.run()

    # evaluate
    evaluate_obj = Evaluate_Accuracy("evaluation", "")
    evaluate_obj.data = result

    print("************ Performance ************")
    score = evaluate_obj.evaluate()

    print("Accuracy:", score)

    plt.plot(range(len(result["loss_list"])), result["loss_list"])
    plt.xlabel("Epoch")
    plt.ylabel("Loss")
    plt.title("MNIST CNN Training Convergence")
    plt.grid(True)
    plt.savefig("result/stage_3_result/mnist_cnn_loss.png")
    plt.show()