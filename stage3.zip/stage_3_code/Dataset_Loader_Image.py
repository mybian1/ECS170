from local_code.base_class.dataset import dataset
import pickle
import numpy as np


class Dataset_Loader_Image(dataset):
    dataset_source_folder_path = None
    dataset_source_file_name = None

    def __init__(self, dName=None, dDescription=None):
        super().__init__(dName, dDescription)

    def load(self):
        print("loading image data...")

        file_path = self.dataset_source_folder_path + self.dataset_source_file_name

        with open(file_path, "rb") as f:
            data = pickle.load(f)

        train_X, train_y = [], []
        test_X, test_y = [], []

        for instance in data["train"]:
            image = np.array(instance["image"])
            label = instance["label"]

            if self.dataset_source_file_name == "ORL":
                label = label - 1

            # ORL image is 112 x 92 x 3, but grayscale, so use one channel
            if image.ndim == 3 and image.shape[2] == 3:
                if self.dataset_source_file_name == "ORL":
                    image = image[:, :, 0]
                    image = image.reshape(1, image.shape[0], image.shape[1])
                else:
                    # CIFAR: 32 x 32 x 3 -> 3 x 32 x 32
                    image = np.transpose(image, (2, 0, 1))

            # MNIST image is 28 x 28
            elif image.ndim == 2:
                image = image.reshape(1, image.shape[0], image.shape[1])

            image = image / 255.0

            train_X.append(image)
            train_y.append(label)

        for instance in data["test"]:
            image = np.array(instance["image"])
            label = instance["label"]

            if self.dataset_source_file_name == "ORL":
                label = label - 1

            if image.ndim == 3 and image.shape[2] == 3:
                if self.dataset_source_file_name == "ORL":
                    image = image[:, :, 0]
                    image = image.reshape(1, image.shape[0], image.shape[1])
                else:
                    image = np.transpose(image, (2, 0, 1))

            elif image.ndim == 2:
                image = image.reshape(1, image.shape[0], image.shape[1])

            image = image / 255.0

            test_X.append(image)
            test_y.append(label)

        return {
            "train": {"X": np.array(train_X), "y": np.array(train_y)},
            "test": {"X": np.array(test_X), "y": np.array(test_y)}
        }