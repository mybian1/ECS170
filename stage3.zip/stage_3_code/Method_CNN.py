from local_code.base_class.method import method
import torch
from torch import nn
import numpy as np
import matplotlib.pyplot as plt


class Method_CNN(method, nn.Module):
    data = None

    def __init__(self, mName, mDescription, input_channel=1, num_classes=10, image_height=28, image_width=28):
        method.__init__(self, mName, mDescription)
        nn.Module.__init__(self)

        self.max_epoch = 20
        self.learning_rate = 0.001
        self.batch_size = 64

        self.input_channel = input_channel
        self.num_classes = num_classes
        self.image_height = image_height
        self.image_width = image_width

        self.conv_layers = nn.Sequential(
            nn.Conv2d(input_channel, 16, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.MaxPool2d(2),

            nn.Conv2d(16, 32, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.MaxPool2d(2)
        )

        final_height = image_height // 4
        final_width = image_width // 4

        self.fc_layers = nn.Sequential(
            nn.Flatten(),
            nn.Linear(32 * final_height * final_width, 128),
            nn.ReLU(),
            nn.Linear(128, num_classes)
        )

        self.loss_list = []

    def forward(self, x):
        x = self.conv_layers(x)
        x = self.fc_layers(x)
        return x

    def train_model(self, X, y):
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.to(device)

        X = torch.FloatTensor(np.array(X)).to(device)
        y = torch.LongTensor(np.array(y)).to(device)

        optimizer = torch.optim.Adam(self.parameters(), lr=self.learning_rate)
        loss_function = nn.CrossEntropyLoss()

        n = X.shape[0]

        for epoch in range(self.max_epoch):
            permutation = torch.randperm(n)
            total_loss = 0

            for i in range(0, n, self.batch_size):
                index = permutation[i:i + self.batch_size]

                batch_X = X[index]
                batch_y = y[index]

                y_pred = self.forward(batch_X)
                loss = loss_function(y_pred, batch_y)

                optimizer.zero_grad()
                loss.backward()
                optimizer.step()

                total_loss += loss.item()

            avg_loss = total_loss / (n // self.batch_size + 1)
            self.loss_list.append(avg_loss)

            print("Epoch:", epoch, "Loss:", avg_loss)

    def test(self, X):
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.to(device)

        X = torch.FloatTensor(np.array(X)).to(device)

        self.eval()
        with torch.no_grad():
            y_pred = self.forward(X)
            predicted = y_pred.max(1)[1]

        return predicted.cpu().numpy()

    def run(self):
        print("method running...")
        print("--start training...")
        self.train_model(self.data["train"]["X"], self.data["train"]["y"])

        print("--start testing...")
        pred_y = self.test(self.data["test"]["X"])

        return {
            "pred_y": pred_y,
            "true_y": self.data["test"]["y"],
            "loss_list": self.loss_list
        }