import sys
from pathlib import Path

import torch
import torch.nn.functional as F
import matplotlib.pyplot as plt
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score


# ---------------------------------------------------------
# Find project root
# script_gcn.py is inside script/stage_5_script
# so parents[2] is the project root
# ---------------------------------------------------------
ROOT_DIR = Path(__file__).resolve().parents[2]
sys.path.append(str(ROOT_DIR))

from local_code.stage_5_code.Dataset_Loader_Node_Classification import Dataset_Loader
from local_code.stage_5_code.Method_GCN import GCN


def evaluate(model, features, adj, labels, idx):
    model.eval()

    with torch.no_grad():
        output = model(features, adj)
        pred = torch.argmax(output[idx], dim=1)

    true = labels[idx]

    y_true = true.cpu().numpy()
    y_pred = pred.cpu().numpy()

    acc = accuracy_score(y_true, y_pred)
    precision = precision_score(y_true, y_pred, average="macro", zero_division=0)
    recall = recall_score(y_true, y_pred, average="macro", zero_division=0)
    f1 = f1_score(y_true, y_pred, average="macro", zero_division=0)

    return acc, precision, recall, f1


def train_one_dataset(dataset_name, epochs=200, hidden_dim=16, lr=0.01, weight_decay=5e-4):
    print("=" * 60)
    print("Training dataset:", dataset_name)
    print("=" * 60)

    # -------------------------------
    # Load data
    # -------------------------------
    loader = Dataset_Loader()
    loader.dataset_name = dataset_name
    loader.dataset_source_folder_path = ROOT_DIR / "data" / "stage_5_data" / dataset_name

    data = loader.load()

    graph = data["graph"]
    split = data["train_test_val"]

    features = graph["X"]
    labels = graph["y"]
    adj = graph["utility"]["A"]

    idx_train = split["idx_train"]
    idx_val = split["idx_val"]
    idx_test = split["idx_test"]

    input_dim = features.shape[1]
    output_dim = int(labels.max().item()) + 1

    print("Number of nodes:", features.shape[0])
    print("Number of features:", input_dim)
    print("Number of classes:", output_dim)
    print("Train nodes:", len(idx_train))
    print("Validation nodes:", len(idx_val))
    print("Test nodes:", len(idx_test))

    # -------------------------------
    # Device: GPU if available
    # -------------------------------
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print("Using device:", device)

    features = features.to(device)
    labels = labels.to(device)
    adj = adj.coalesce().to(device)

    idx_train = idx_train.to(device)
    idx_val = idx_val.to(device)
    idx_test = idx_test.to(device)

    # -------------------------------
    # Model
    # -------------------------------
    model = GCN(
        input_dim=input_dim,
        hidden_dim=hidden_dim,
        output_dim=output_dim,
        dropout=0.5
    ).to(device)

    optimizer = torch.optim.Adam(
        model.parameters(),
        lr=lr,
        weight_decay=weight_decay
    )

    train_losses = []
    val_losses = []
    train_accs = []
    val_accs = []

    # -------------------------------
    # Training loop
    # -------------------------------
    for epoch in range(epochs):
        model.train()

        optimizer.zero_grad()

        output = model(features, adj)

        train_loss = F.cross_entropy(output[idx_train], labels[idx_train])
        train_loss.backward()
        optimizer.step()

        # validation loss
        model.eval()
        with torch.no_grad():
            output = model(features, adj)
            val_loss = F.cross_entropy(output[idx_val], labels[idx_val])

        train_acc, _, _, _ = evaluate(model, features, adj, labels, idx_train)
        val_acc, _, _, _ = evaluate(model, features, adj, labels, idx_val)

        train_losses.append(train_loss.item())
        val_losses.append(val_loss.item())
        train_accs.append(train_acc)
        val_accs.append(val_acc)

        if (epoch + 1) % 10 == 0:
            print(
                "Epoch {:03d} | Train Loss {:.4f} | Val Loss {:.4f} | Train Acc {:.4f} | Val Acc {:.4f}".format(
                    epoch + 1,
                    train_loss.item(),
                    val_loss.item(),
                    train_acc,
                    val_acc
                )
            )

    # -------------------------------
    # Final test result
    # -------------------------------
    test_acc, test_precision, test_recall, test_f1 = evaluate(
        model, features, adj, labels, idx_test
    )

    print()
    print("Final Test Results for", dataset_name)
    print("Accuracy :", round(test_acc, 4))
    print("Precision:", round(test_precision, 4))
    print("Recall   :", round(test_recall, 4))
    print("F1-score :", round(test_f1, 4))

    # -------------------------------
    # Save learning curve
    # -------------------------------
    result_dir = ROOT_DIR / "result" / "stage_5_result"
    result_dir.mkdir(parents=True, exist_ok=True)

    plt.figure()
    plt.plot(train_losses, label="Train Loss")
    plt.plot(val_losses, label="Validation Loss")
    plt.xlabel("Epoch")
    plt.ylabel("Loss")
    plt.title(dataset_name + " GCN Loss Curve")
    plt.legend()
    plt.savefig(result_dir / f"{dataset_name}_gcn_loss.png")
    plt.close()

    plt.figure()
    plt.plot(train_accs, label="Train Accuracy")
    plt.plot(val_accs, label="Validation Accuracy")
    plt.xlabel("Epoch")
    plt.ylabel("Accuracy")
    plt.title(dataset_name + " GCN Accuracy Curve")
    plt.legend()
    plt.savefig(result_dir / f"{dataset_name}_gcn_accuracy.png")
    plt.close()

    return {
        "dataset": dataset_name,
        "accuracy": test_acc,
        "precision": test_precision,
        "recall": test_recall,
        "f1": test_f1
    }


def main():
    datasets = ["cora", "citeseer", "pubmed"]

    all_results = []

    for dataset_name in datasets:
        result = train_one_dataset(
            dataset_name=dataset_name,
            epochs=200,
            hidden_dim=16,
            lr=0.01,
            weight_decay=5e-4
        )
        all_results.append(result)

    print()
    print("=" * 60)
    print("Summary Table")
    print("=" * 60)
    print("{:<10} {:<10} {:<10} {:<10} {:<10}".format(
        "Dataset", "Accuracy", "Precision", "Recall", "F1"
    ))

    for r in all_results:
        print("{:<10} {:<10.4f} {:<10.4f} {:<10.4f} {:<10.4f}".format(
            r["dataset"],
            r["accuracy"],
            r["precision"],
            r["recall"],
            r["f1"]
        ))


if __name__ == "__main__":
    main()